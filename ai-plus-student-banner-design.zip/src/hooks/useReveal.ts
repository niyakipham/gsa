import { useEffect } from "react";

/**
 * Hiện dần các phần tử `.reveal` khi cuộn tới.
 *
 * Dùng thuộc tính `data-revealed` thay vì thêm class: React chỉ quản lý những
 * thuộc tính nó render, nên khi component re-render và gán lại `className`
 * (ví dụ khi mở/đóng FAQ) trạng thái đã hiện KHÔNG bị xoá mất.
 */
export function useReveal() {
  useEffect(() => {
    const show = (el: Element) => el.setAttribute("data-revealed", "");

    if (!("IntersectionObserver" in window)) {
      document.querySelectorAll(".reveal").forEach(show);
      return;
    }

    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            show(e.target);
            io.unobserve(e.target);
          }
        }
      },
      { threshold: 0.12, rootMargin: "0px 0px -8% 0px" }
    );

    const observeAll = () =>
      document.querySelectorAll(".reveal:not([data-revealed])").forEach((el) => io.observe(el));
    observeAll();

    // Theo dõi phần tử .reveal được thêm sau (render có điều kiện)
    const mo = new MutationObserver(observeAll);
    mo.observe(document.body, { childList: true, subtree: true });

    return () => {
      io.disconnect();
      mo.disconnect();
    };
  }, []);
}
