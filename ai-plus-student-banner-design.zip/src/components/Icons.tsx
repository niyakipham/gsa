import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement> & { size?: number };

const base = (size: number | undefined, props: P) => ({
  width: size ?? 24,
  height: size ?? 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  "aria-hidden": true,
  ...props,
});

export const SPARKLE_PATH = "M12 0C12.8 6.6 17.4 11.2 24 12C17.4 12.8 12.8 17.4 12 24C11.2 17.4 6.6 12.8 0 12C6.6 11.2 11.2 6.6 12 0Z";

export function Sparkle({ size = 20, ...props }: P) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" {...props}>
      <path d={SPARKLE_PATH} fill="currentColor" />
    </svg>
  );
}

export function GeminiMark({ size = 24, id = "gm", ...props }: P & { id?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" {...props}>
      <defs>
        <linearGradient id={id} x1="0" y1="24" x2="24" y2="0">
          <stop stopColor="#346BF0" />
          <stop offset=".55" stopColor="#4EA0FF" />
          <stop offset="1" stopColor="#9B72F2" />
        </linearGradient>
      </defs>
      <path d={SPARKLE_PATH} fill={`url(#${id})`} />
    </svg>
  );
}

export function GoogleDots({ className = "" }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-1.5 ${className}`} aria-hidden="true">
      {["#4285F4", "#EA4335", "#FBBC04", "#34A853"].map((c) => (
        <span key={c} className="h-2 w-2 rounded-full" style={{ background: c }} />
      ))}
    </span>
  );
}

export const ArrowRight = ({ size, ...p }: P) => (
  <svg {...base(size, p)} strokeWidth={2.6}>
    <path d="M5 12h14M13 6l6 6-6 6" />
  </svg>
);
export const ArrowUpRight = ({ size, ...p }: P) => (
  <svg {...base(size, p)} strokeWidth={2.4}>
    <path d="M7 17 17 7M8 7h9v9" />
  </svg>
);
export const ScanIcon = ({ size, ...p }: P) => (
  <svg {...base(size, p)}>
    <path d="M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2" />
    <rect x="8" y="8" width="3" height="3" rx=".6" fill="currentColor" stroke="none" />
    <rect x="13" y="8" width="3" height="3" rx=".6" fill="currentColor" stroke="none" />
    <rect x="8" y="13" width="3" height="3" rx=".6" fill="currentColor" stroke="none" />
    <path d="M13 13h3v3h-3z" />
  </svg>
);
export const ShieldCheck = ({ size, ...p }: P) => (
  <svg {...base(size, p)}>
    <path d="M12 3l7 3v5c0 5-3.2 8.4-7 10-3.8-1.6-7-5-7-10V6l7-3z" />
    <path d="m9 12 2 2 4-4" />
  </svg>
);
export const Rocket = ({ size, ...p }: P) => (
  <svg {...base(size, p)}>
    <path d="M14.5 4.5c2.5-1 5-1 5 0s0 2.5-1 5L12 16l-4-4 6.5-7.5z" />
    <path d="M8 12l-3 1 2 2 2 2 1-3M12 16l1 3-3-1" />
    <circle cx="15" cy="9" r="1.2" fill="currentColor" stroke="none" />
  </svg>
);
export const BrainIcon = ({ size, ...p }: P) => (
  <svg {...base(size, p)}>
    <path d="M9 4a3 3 0 0 0-3 3v1a3 3 0 0 0-2 3 3 3 0 0 0 2 3v1a3 3 0 0 0 3 3h1V4H9zM15 4a3 3 0 0 1 3 3v1a3 3 0 0 1 2 3 3 3 0 0 1-2 3v1a3 3 0 0 1-3 3h-1V4h1z" />
    <path d="M10 9h-1M14 9h1M10 15H9M14 15h1" />
  </svg>
);
export const NotebookIcon = ({ size, ...p }: P) => (
  <svg {...base(size, p)}>
    <rect x="5" y="3" width="14" height="18" rx="2" />
    <path d="M9 3v18M12 8h4M12 12h4" />
    <path d="M3 7h2M3 11h2M3 15h2" />
  </svg>
);
export const FilmIcon = ({ size, ...p }: P) => (
  <svg {...base(size, p)}>
    <rect x="3" y="5" width="18" height="14" rx="2.5" />
    <path d="m10 9 5 3-5 3V9z" fill="currentColor" stroke="none" />
    <path d="M3 9h3M3 15h3M18 9h3M18 15h3" />
  </svg>
);
export const CloudIcon = ({ size, ...p }: P) => (
  <svg {...base(size, p)}>
    <path d="M7 18a4 4 0 0 1-.6-7.95A6 6 0 0 1 18 9a4.5 4.5 0 0 1 0 9H7z" />
    <path d="M12 12v5M9.5 14.5 12 12l2.5 2.5" />
  </svg>
);
export const CheckIcon = ({ size, ...p }: P) => (
  <svg {...base(size, p)} strokeWidth={3}>
    <path d="m5 12 5 5 9-10" />
  </svg>
);
export const BellIcon = ({ size, ...p }: P) => (
  <svg {...base(size, p)}>
    <path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2h-15L6 16z" />
    <path d="M10 20a2 2 0 0 0 4 0" />
  </svg>
);
export const CloseIcon = ({ size, ...p }: P) => (
  <svg {...base(size, p)} strokeWidth={2.8}>
    <path d="M6 6l12 12M18 6 6 18" />
  </svg>
);
export const ExpandIcon = ({ size, ...p }: P) => (
  <svg {...base(size, p)} strokeWidth={2.4}>
    <path d="M9 3H3v6M15 21h6v-6M21 9V3h-6M3 15v6h6" />
  </svg>
);
export const PlusIcon = ({ size, ...p }: P) => (
  <svg {...base(size, p)} strokeWidth={2.6}>
    <path d="M12 5v14M5 12h14" />
  </svg>
);
export const MenuIcon = ({ size, ...p }: P) => (
  <svg {...base(size, p)} strokeWidth={2.6}>
    <path d="M4 7h16M4 12h16M4 17h16" />
  </svg>
);
