import { useRef, useState } from "react";
import { FAQS } from "../config";
import { PlusIcon } from "./Icons";

export default function Faq() {
  // Cho phép mở nhiều mục cùng lúc
  const [open, setOpen] = useState<Set<number>>(() => new Set([0]));
  const btnRefs = useRef<(HTMLButtonElement | null)[]>([]);

  const toggle = (i: number) =>
    setOpen((prev) => {
      const next = new Set(prev);
      if (next.has(i)) next.delete(i);
      else next.add(i);
      return next;
    });

  const allOpen = open.size === FAQS.length;
  const toggleAll = () => setOpen(allOpen ? new Set() : new Set(FAQS.map((_, i) => i)));

  // Điều hướng bàn phím: ↑ ↓ Home End
  const onKey = (e: React.KeyboardEvent, i: number) => {
    const last = FAQS.length - 1;
    let next = -1;
    if (e.key === "ArrowDown") next = i === last ? 0 : i + 1;
    else if (e.key === "ArrowUp") next = i === 0 ? last : i - 1;
    else if (e.key === "Home") next = 0;
    else if (e.key === "End") next = last;
    if (next >= 0) {
      e.preventDefault();
      btnRefs.current[next]?.focus();
    }
  };

  return (
    <div>
      <div className="reveal mb-4 flex items-center justify-between gap-3">
        <span className="f-mono text-[11px] uppercase tracking-[0.22em] text-[#5f5f5f]">
          {String(open.size).padStart(2, "0")} / {String(FAQS.length).padStart(2, "0")} đang mở
        </span>
        <button
          type="button"
          onClick={toggleAll}
          className="f-mono rounded-full border border-[#2e2e2e] px-4 py-2 text-[11px] font-bold uppercase tracking-[0.18em] text-[#a3a3a3] transition hover:border-[#00e5ff] hover:text-[#00e5ff]"
        >
          {allOpen ? "Thu gọn tất cả" : "Mở tất cả"}
        </button>
      </div>

      <div className="grid gap-3">
        {FAQS.map((f, i) => {
          const isOpen = open.has(i);
          return (
            /* Lớp ngoài: class CỐ ĐỊNH, chỉ lo hiệu ứng xuất hiện */
            <div key={f.q} className="reveal" style={{ ["--d" as string]: `${i * 70}ms` }}>
              {/* Lớp trong: class thay đổi theo trạng thái */}
              <div
                data-open={isOpen}
                className={`faq-item relative overflow-hidden rounded-[20px] border ${
                  isOpen ? "border-[#00e5ff]/60 bg-[#0b1215]" : "border-[#232323] bg-[#0d0d0d] hover:border-[#3a3a3a] hover:bg-[#101010]"
                }`}
              >
                <span className="faq-bar absolute bottom-0 left-0 top-0 w-[3px] bg-[#00e5ff]" aria-hidden="true" />
                <h3>
                  <button
                    ref={(el) => {
                      btnRefs.current[i] = el;
                    }}
                    type="button"
                    id={`faq-btn-${i}`}
                    aria-expanded={isOpen}
                    aria-controls={`faq-panel-${i}`}
                    onClick={() => toggle(i)}
                    onKeyDown={(e) => onKey(e, i)}
                    className="flex w-full items-center justify-between gap-4 px-5 py-5 text-left sm:px-6"
                  >
                    <span className="flex items-start gap-4 text-[15px] font-bold leading-snug text-[#f4f4f4] sm:text-[17px]">
                      <span className={`f-mono mt-0.5 shrink-0 text-sm transition-colors ${isOpen ? "text-[#00e5ff]" : "text-[#5f5f5f]"}`}>
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      {f.q}
                    </span>
                    <span
                      className={`grid h-9 w-9 shrink-0 place-items-center rounded-full border-2 transition duration-300 ${
                        isOpen ? "rotate-45 border-[#00e5ff] bg-[#00e5ff] text-[#060606]" : "border-[#3a3a3a] text-[#f4f4f4]"
                      }`}
                      aria-hidden="true"
                    >
                      <PlusIcon size={16} />
                    </span>
                  </button>
                </h3>
                <div
                  id={`faq-panel-${i}`}
                  role="region"
                  aria-labelledby={`faq-btn-${i}`}
                  className="grid transition-[grid-template-rows,opacity] duration-300 ease-out"
                  style={{ gridTemplateRows: isOpen ? "1fr" : "0fr", opacity: isOpen ? 1 : 0 }}
                >
                  <div className="overflow-hidden">
                    <p className="px-5 pb-6 pl-[3.35rem] text-[15px] leading-relaxed text-[#a3a3a3] sm:px-6 sm:pl-[3.6rem]">{f.a}</p>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
