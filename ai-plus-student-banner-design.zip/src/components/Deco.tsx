/* Thành phần trang trí – phong cách streetwear/glitch */

const GLYPH: Record<string, string[]> = {
  "#": ["01010", "01010", "11111", "01010", "01010", "11111", "01010"],
  A: ["01110", "10001", "10001", "11111", "10001", "10001", "10001"],
  I: ["11111", "00100", "00100", "00100", "00100", "00100", "11111"],
  P: ["11110", "10001", "10001", "11110", "10000", "10000", "10000"],
  L: ["10000", "10000", "10000", "10000", "10000", "10000", "11111"],
  U: ["10001", "10001", "10001", "10001", "10001", "10001", "01110"],
  S: ["01111", "10000", "10000", "01110", "00001", "00001", "11110"],
  M: ["10001", "11011", "10101", "10101", "10001", "10001", "10001"],
  O: ["01110", "10001", "10001", "10001", "10001", "10001", "01110"],
  N: ["10001", "11001", "10101", "10011", "10001", "10001", "10001"],
  T: ["11111", "00100", "00100", "00100", "00100", "00100", "00100"],
  H: ["10001", "10001", "10001", "11111", "10001", "10001", "10001"],
  G: ["01111", "10000", "10000", "10111", "10001", "10001", "01111"],
  E: ["11111", "10000", "10000", "11110", "10000", "10000", "11111"],
  R: ["11110", "10001", "10001", "11110", "10100", "10010", "10001"],
  F: ["11111", "10000", "10000", "11110", "10000", "10000", "10000"],
  Y: ["10001", "10001", "01010", "00100", "00100", "00100", "00100"],
  V: ["10001", "10001", "10001", "10001", "01010", "01010", "00100"],
  D: ["11110", "10001", "10001", "10001", "10001", "10001", "11110"],
  B: ["11110", "10001", "10001", "11110", "10001", "10001", "11110"],
  W: ["10001", "10001", "10001", "10101", "10101", "10101", "01010"],
  K: ["10001", "10010", "10100", "11000", "10100", "10010", "10001"],
  C: ["01110", "10001", "10000", "10000", "10000", "10001", "01110"],
  X: ["10001", "10001", "01010", "00100", "01010", "10001", "10001"],
  Z: ["11111", "00001", "00010", "00100", "01000", "10000", "11111"],
  "0": ["01110", "10001", "10011", "10101", "11001", "10001", "01110"],
  "1": ["00100", "01100", "00100", "00100", "00100", "00100", "01110"],
  "2": ["01110", "10001", "00001", "00010", "00100", "01000", "11111"],
  "3": ["11110", "00001", "00001", "01110", "00001", "00001", "11110"],
  "6": ["01110", "10000", "10000", "11110", "10001", "10001", "01110"],
  "+": ["00000", "00100", "00100", "11111", "00100", "00100", "00000"],
  "?": ["01110", "10001", "00001", "00010", "00100", "00000", "00100"],
  ".": ["00000", "00000", "00000", "00000", "00000", "00110", "00110"],
};

/** Chữ pixel 5×7 – dùng cho sticker và khối neon */
export function PixelText({
  text,
  className = "",
  color = "#f4f4f4",
  accent = "#00e5ff",
  accentChars = "",
  block = false,
}: {
  text: string;
  className?: string;
  color?: string;
  accent?: string;
  accentChars?: string;
  block?: boolean;
}) {
  return (
    <span className={`inline-flex items-end gap-[0.16em] ${className}`} aria-label={text}>
      {text.split("").map((ch, i) => {
        if (ch === " ") return <span key={i} className="w-[0.42em]" />;
        const rows = GLYPH[ch] || GLYPH["?"];
        const cols = rows[0].length;
        return (
          <span key={i} className="relative inline-block h-[1em]" aria-hidden="true">
            <svg viewBox={`0 0 ${cols} ${rows.length}`} className="h-full w-auto overflow-visible">
              {rows.flatMap((row, y) =>
                row.split("").map((bit, x) =>
                  bit === "1" ? (
                    <rect
                      key={`${x}-${y}`}
                      x={x + 0.06}
                      y={y + 0.06}
                      width={block ? 0.94 : 0.88}
                      height={block ? 0.94 : 0.88}
                      rx={block ? 0.28 : 0.14}
                      fill={accentChars.includes(ch) ? accent : color}
                    />
                  ) : null
                )
              )}
            </svg>
          </span>
        );
      })}
    </span>
  );
}

/** Vòng tròn trắng dày – như vòng "O" trong ảnh */
export function BigRing({ className = "", thick = 14 }: { className?: string; thick?: number }) {
  return (
    <span
      className={`pointer-events-none block rounded-full border-[#f4f4f4] ${className}`}
      style={{ borderWidth: thick }}
      aria-hidden="true"
    />
  );
}

/** Dấu X trắng dày */
export function XMark({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
      <path d="M8 6 L20 6 L24 12 L28 6 L40 6 L30 24 L40 42 L28 42 L24 36 L20 42 L8 42 L18 24 Z" fill="currentColor" />
    </svg>
  );
}

/** Dấu ? trong vòng tròn */
export function QuestionCircle({ className = "" }: { className?: string }) {
  return (
    <span className={`relative grid place-items-center rounded-full border-[1.6px] border-[#f4f4f4]/80 ${className}`} aria-hidden="true">
      <span className="f-mono text-[1.05em] font-bold leading-none">?</span>
    </span>
  );
}

/** Chữ nền mờ khổng lồ */
export function GhostWord({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <span className={`ghost pointer-events-none absolute select-none leading-[0.8] ${className}`} aria-hidden="true">
      {children}
    </span>
  );
}

/** Chữ số outline khổng lồ */
export function OutlineNum({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <span className={`f-display outline-num pointer-events-none leading-[0.8] ${className}`} aria-hidden="true">
      {children}
    </span>
  );
}

/** 4 góc tick cho khung */
export function CornerTicks({ className = "" }: { className?: string }) {
  const s = "absolute h-5 w-5 border-[#f4f4f4]/60";
  return (
    <span className={className} aria-hidden="true">
      <span className={`${s} left-0 top-0 border-l-2 border-t-2 rounded-tl-[14px]`} />
      <span className={`${s} right-0 top-0 border-r-2 border-t-2 rounded-tr-[14px]`} />
      <span className={`${s} bottom-0 left-0 border-b-2 border-l-2 rounded-bl-[14px]`} />
      <span className={`${s} bottom-0 right-0 border-b-2 border-r-2 rounded-br-[14px]`} />
    </span>
  );
}

/** Sao 4 cánh nhỏ */
export function Spark4({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
      <path d="M12 0 L13.1 9.4 L24 12 L13.1 14.6 L12 24 L10.9 14.6 L0 12 L10.9 9.4 Z" />
    </svg>
  );
}
