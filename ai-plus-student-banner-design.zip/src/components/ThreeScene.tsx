import { useEffect, useRef } from "react";
import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/examples/jsm/postprocessing/OutputPass.js";

/* ---------- Nền đen + quầng cyan + scanline + hạt nhiễu ---------- */
const BG_VERT = /* glsl */ `
  varying vec2 vUv;
  void main() { vUv = uv; gl_Position = vec4(position.xy, 1.0, 1.0); }
`;
const BG_FRAG = /* glsl */ `
  precision highp float;
  varying vec2 vUv;
  uniform float uTime; uniform float uAspect; uniform vec2 uMouse;
  float hash(vec2 p){ p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
  float noise(vec2 p){
    vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1,0)), f.x), mix(hash(i + vec2(0,1)), hash(i + vec2(1,1)), f.x), f.y);
  }
  float fbm(vec2 p){ float v = 0.0; float a = 0.5; mat2 m = mat2(1.6, 1.2, -1.2, 1.6);
    for (int i = 0; i < 3; i++) { v += a * noise(p); p = m * p; a *= 0.5; } return v; }
  void main(){
    vec2 uv = vUv;
    vec2 asp = vec2(uAspect, 1.0);
    vec2 p = uv * asp;
    float t = uTime * 0.04;
    float n = fbm(p * 1.2 + t);

    vec3 col = vec3(0.024, 0.024, 0.028);
    // quầng cyan mờ phía sau cụm pixel (sau pill AI PLUS)
    col += vec3(0.0, 0.42, 0.5) * exp(-length((uv - vec2(0.22, 0.45)) * asp) * 2.2) * 0.55;
    // quầng tím rất nhạt góc phải trên
    col += vec3(0.16, 0.10, 0.5) * exp(-length((uv - vec2(0.92, 0.88)) * asp) * 2.2) * 0.3;
    // đốm sáng theo chuột
    vec2 mp = vec2((uMouse.x * 0.5 + 0.5) * uAspect, uMouse.y * 0.5 + 0.5);
    col += vec3(0.1, 0.12, 0.3) * exp(-length(p - mp) * 1.8) * 0.5;
    // biến thể noise rất nhẹ
    col += (n - 0.5) * 0.02;
    // scanline rất nhẹ
    col *= 0.985 + 0.015 * sin(uv.y * 720.0 + t * 2.0);
    // vignette
    col *= 0.82 + 0.18 * (1.0 - length((uv - 0.5) * vec2(1.1, 1.0)) * 1.15);
    // hạt nhiễu
    col += (hash(gl_FragCoord.xy + floor(t * 14.0)) - 0.5) * 0.05;
    gl_FragColor = vec4(col, 1.0);
  }
`;

/* ---------- Voxel map – cụm pixel cyan như ảnh ---------- */
const VOXEL_MAP = [
  "..CC...",
  "..cWc..",
  ".CCCCC.",
  "CCCCCCC",
  "CcCCCCC",
  ".CCCCC.",
  "..CWC..",
  "..C.C..",
  "..C.C..",
];
// C = cyan, c = cyan đậm, W = trắng, . = trống

function buildVoxelCluster() {
  const group = new THREE.Group();
  const box = new THREE.BoxGeometry(0.27, 0.27, 0.27);
  const matCyan = new THREE.MeshStandardMaterial({ color: "#00e5ff", emissive: new THREE.Color("#00a8c8"), emissiveIntensity: 1.15, roughness: 0.3, metalness: 0.1 });
  const matDeep = new THREE.MeshStandardMaterial({ color: "#007d9c", emissive: new THREE.Color("#004d63"), emissiveIntensity: 0.95, roughness: 0.4, metalness: 0.1 });
  const matWhite = new THREE.MeshStandardMaterial({ color: "#f4f4f4", emissive: new THREE.Color("#7f8f9c"), emissiveIntensity: 0.35, roughness: 0.35, metalness: 0.05 });

  const cells: { x: number; y: number; mat: THREE.Material }[] = [];
  const rows = VOXEL_MAP.length;
  const cols = VOXEL_MAP[0].length;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const ch = VOXEL_MAP[r][c];
      if (ch === ".") continue;
      const mat = ch === "c" ? matDeep : ch === "W" ? matWhite : matCyan;
      const z = (Math.random() - 0.5) * 0.22;
      cells.push({ x: (c - cols / 2) * 0.27, y: (rows / 2 - r) * 0.27, mat });
      const m = new THREE.Mesh(box, mat);
      m.position.set((c - cols / 2) * 0.27, (rows / 2 - r) * 0.27, z);
      group.add(m);
    }
  }
  // vài khối rời (glitch detached)
  const off: [number, number, THREE.Material][] = [
    [-1.55, 0.55, matCyan],
    [-1.35, -0.1, matDeep],
    [1.5, 0.9, matCyan],
    [1.3, -0.7, matWhite],
    [-0.9, -1.5, matCyan],
  ];
  for (const [x, y, m] of off) {
    const b2 = new THREE.Mesh(box, m);
    b2.position.set(x, y, (Math.random() - 0.5) * 0.3);
    b2.scale.setScalar(0.7 + Math.random() * 0.4);
    group.add(b2);
  }
  return { group, cells: group.children };
}

function sparkTex() {
  const cv = document.createElement("canvas");
  cv.width = cv.height = 64;
  const ctx = cv.getContext("2d")!;
  const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  g.addColorStop(0, "rgba(255,255,255,1)");
  g.addColorStop(0.35, "rgba(220,240,255,0.4)");
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 64, 64);
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export default function ThreeScene({ className }: { className?: string }) {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "high-performance" });
    } catch {
      return;
    }
    const dpr = Math.min(window.devicePixelRatio || 1, window.innerWidth < 1024 ? 1.4 : 1.75);
    renderer.setPixelRatio(dpr);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    mount.appendChild(renderer.domElement);
    Object.assign(renderer.domElement.style, { width: "100%", height: "100%", display: "block" });

    const scene = new THREE.Scene();
    const FOV = 34;
    const CAM_Z = 9;
    const camera = new THREE.PerspectiveCamera(FOV, 1, 0.1, 90);
    camera.position.set(0, 0, CAM_Z);

    // ánh sáng: cyan neon + trắng rim
    const keyL = new THREE.DirectionalLight(0xbfefff, 2.6);
    keyL.position.set(-4, 6, 8);
    scene.add(keyL);
    const rim = new THREE.DirectionalLight(0x8fe0ff, 2.2);
    rim.position.set(6, 2, -3);
    scene.add(rim);
    const fill = new THREE.PointLight(0x00e5ff, 45, 30);
    fill.position.set(-2, 0, 5);
    scene.add(fill);
    const warm = new THREE.PointLight(0xffffff, 25, 26);
    warm.position.set(4, 4, 5);
    scene.add(warm);

    const bgMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uAspect: { value: 1 }, uMouse: { value: new THREE.Vector2() } },
      vertexShader: BG_VERT,
      fragmentShader: BG_FRAG,
      depthTest: false,
      depthWrite: false,
    });
    const bg = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), bgMat);
    bg.frustumCulled = false;
    bg.renderOrder = -10;
    scene.add(bg);

    type Item = { obj: THREE.Object3D; d: [number, number]; m: [number, number] | null; s: number; depth: number; bob: number; phase: number; spin: [number, number, number]; base: THREE.Vector3 };
    const items: Item[] = [];
    const add = (obj: THREE.Object3D, o: Omit<Item, "obj" | "base">) => {
      scene.add(obj);
      items.push({ obj, base: new THREE.Vector3(), ...o });
    };

    // cụm voxel
    const cluster = buildVoxelCluster();
    const clusterBoxes = cluster.group.children.filter((c) => (c as THREE.Mesh).isMesh) as THREE.Mesh[];
    const jitter = new Float32Array(clusterBoxes.length * 3);
    const basePos = clusterBoxes.map((m) => m.position.clone());
    let glitchT = 0;
    add(cluster.group, { d: [0.22, 0.45], m: [0.5, 0], s: 0.42, depth: 0.5, bob: 0.02, phase: 0, spin: [0, 0.05, 0] });

    // vòng trắng (như vòng O trong ảnh)
    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(0.62, 0.085, 20, 90),
      new THREE.MeshStandardMaterial({ color: "#f4f4f4", roughness: 0.5, metalness: 0.05 })
    );
    add(ring, { d: [0.5, 0.78], m: null, s: 0.3, depth: 0.9, bob: 0.05, phase: 1, spin: [0, 0, 0.3] });

    // khối wireframe
    const wire = new THREE.LineSegments(
      new THREE.EdgesGeometry(new THREE.BoxGeometry(0.55, 0.55, 0.55)),
      new THREE.LineBasicMaterial({ color: 0xf4f4f4, transparent: true, opacity: 0.55 })
    );
    add(wire, { d: [0.88, 0.2], m: null, s: 0.42, depth: 1.4, bob: 0.08, phase: 2, spin: [0.3, 0.45, 0.1] });

    // khối cyan nhỏ bay
    const cubeMat = new THREE.MeshStandardMaterial({ color: "#00e5ff", emissive: new THREE.Color("#0090aa"), emissiveIntensity: 0.7, roughness: 0.3 });
    const cube = new THREE.Mesh(new RoundedBoxGeometry(0.3, 0.3, 0.3, 2, 0.04), cubeMat);
    add(cube, { d: [0.62, 0.72], m: [0.9, 0.5], s: 0.16, depth: 1.2, bob: 0.1, phase: 3, spin: [0.4, 0.5, 0.2] });
    const cube2 = new THREE.Mesh(new RoundedBoxGeometry(0.2, 0.2, 0.2, 2, 0.04), new THREE.MeshStandardMaterial({ color: "#f4f4f4", roughness: 0.4 }));
    add(cube2, { d: [0.06, 0.3], m: [0.08, 0.36], s: 0.1, depth: 1.6, bob: 0.12, phase: 4, spin: [0.5, 0.4, 0.3] });

    // bụi
    const COUNT = 140;
    const pPos = new Float32Array(COUNT * 3);
    for (let i = 0; i < COUNT; i++) {
      pPos[i * 3] = Math.random() * 2 - 1;
      pPos[i * 3 + 1] = Math.random() * 2 - 1;
      pPos[i * 3 + 2] = Math.random() * 2 - 1.2;
    }
    const pGeo = new THREE.BufferGeometry();
    pGeo.setAttribute("position", new THREE.BufferAttribute(pPos, 3));
    const pMat = new THREE.PointsMaterial({ size: 0.045, map: sparkTex(), color: 0xcfefff, transparent: true, opacity: 0.5, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false });
    const points = new THREE.Points(pGeo, pMat);
    scene.add(points);

    const composer = new EffectComposer(renderer);
    composer.addPass(new RenderPass(scene, camera));
    const bloom = new UnrealBloomPass(new THREE.Vector2(1, 1), 0.5, 0.65, 0.72);
    composer.addPass(bloom);
    composer.addPass(new OutputPass());

    let W = 1,
      H = 1,
      VW = 1,
      VH = 1,
      isMobile = false;

    const place = () => {
      const unit = isMobile ? Math.min(W, 460) * (VH / H) : VH;
      const mul = isMobile ? 1.45 : 1;
      for (const it of items) {
        it.obj.visible = true;
        if (isMobile) {
          if (it.m === null) {
            it.obj.visible = false;
            continue;
          }
          const fy = it.obj === cluster.group ? 0.27 : it.m[1] / H;
          const fx = it.obj === cluster.group ? 0.5 : it.m[0];
          it.base.set((fx - 0.5) * VW, (0.5 - fy) * VH, 0);
          it.obj.scale.setScalar((it.obj === cluster.group ? it.s * 0.82 : it.s) * unit * mul);
        } else {
          it.base.set((it.d[0] - 0.5) * VW, (0.5 - it.d[1]) * VH, 0);
          it.obj.scale.setScalar(it.s * unit);
        }
      }
      points.scale.set(VW * 0.55, VH * 0.55, 1);
    };

    const layout = () => {
      W = Math.max(1, mount.clientWidth);
      H = Math.max(1, mount.clientHeight);
      renderer.setSize(W, H, false);
      composer.setSize(W, H);
      bloom.setSize(W / 2, H / 2);
      camera.aspect = W / H;
      camera.updateProjectionMatrix();
      bgMat.uniforms.uAspect.value = W / H;
      VH = 2 * Math.tan(THREE.MathUtils.degToRad(FOV / 2)) * CAM_Z;
      VW = VH * camera.aspect;
      isMobile = W < 1024;
      place();
    };
    layout();
    const ro = new ResizeObserver(() => {
      layout();
      if (reduce) composer.render();
    });
    ro.observe(mount);

    const target = new THREE.Vector2();
    const cur = new THREE.Vector2();
    const onMove = (e: PointerEvent) => target.set((e.clientX / window.innerWidth) * 2 - 1, -((e.clientY / window.innerHeight) * 2 - 1));
    const onLeave = () => target.set(0, 0);
    window.addEventListener("pointermove", onMove, { passive: true });
    window.addEventListener("pointerleave", onLeave);

    let raf = 0;
    let visible = true;
    const io = new IntersectionObserver(([e]) => (visible = e.isIntersecting), { threshold: 0 });
    io.observe(mount);
    let last = performance.now();
    let t = 0;

    const frame = (dt: number) => {
      t += dt;
      cur.lerp(target, 1 - Math.pow(0.001, dt));
      bgMat.uniforms.uTime.value = t;
      bgMat.uniforms.uMouse.value.copy(cur);

      // glitch jitter cho cụm voxel
      glitchT += dt;
      if (glitchT > 2.3) {
        glitchT = 0;
        for (let k = 0; k < 5; k++) {
          const i = Math.floor(Math.random() * clusterBoxes.length);
          jitter[i * 3] = (Math.random() - 0.5) * 0.16;
          jitter[i * 3 + 1] = (Math.random() - 0.5) * 0.16;
          jitter[i * 3 + 2] = (Math.random() - 0.5) * 0.2;
        }
      }
      for (let i = 0; i < clusterBoxes.length; i++) {
        jitter[i * 3] *= 1 - Math.min(1, dt * 5);
        jitter[i * 3 + 1] *= 1 - Math.min(1, dt * 5);
        jitter[i * 3 + 2] *= 1 - Math.min(1, dt * 5);
        const m = clusterBoxes[i];
        m.position.set(basePos[i].x + jitter[i * 3], basePos[i].y + jitter[i * 3 + 1], basePos[i].z + jitter[i * 3 + 2]);
      }

      for (const it of items) {
        it.obj.position.set(
          it.base.x + cur.x * 0.3 * it.depth,
          it.base.y + cur.y * 0.22 * it.depth + Math.sin(t * 0.8 + it.phase) * it.bob,
          it.depth * 0.2
        );
        if (it.spin[0] || it.spin[1] || it.spin[2]) {
          it.obj.rotation.x += it.spin[0] * dt;
          it.obj.rotation.y += it.spin[1] * dt;
          it.obj.rotation.z += it.spin[2] * dt;
        }
      }
      ring.rotation.x = 1.05 + cur.y * 0.15;
      ring.rotation.y = 0.35 + cur.x * 0.2;

      points.rotation.z = Math.sin(t * 0.08) * 0.05;
      points.position.set(cur.x * 0.2, Math.sin(t * 0.25) * 0.12 + cur.y * 0.15, 0);
      pMat.opacity = 0.4 + Math.sin(t * 2) * 0.12;

      composer.render();
    };

    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      if (!visible) return;
      frame(dt);
    };

    if (reduce) frame(0.016);
    else raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerleave", onLeave);
      scene.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.geometry) m.geometry.dispose();
        const mat = m.material as THREE.Material | THREE.Material[] | undefined;
        if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
        else if (mat) {
          (mat as THREE.Material & { map?: THREE.Texture | null }).map?.dispose();
          mat.dispose();
        }
      });
      composer.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === mount) mount.removeChild(renderer.domElement);
    };
  }, []);

  return <div ref={mountRef} className={className} aria-hidden="true" />;
}
