import { useEffect, useRef, useState } from "react";
import qrImg from "../assets/qr.png?inline";
import { ArrowUpRight, CloseIcon, ExpandIcon } from "./Icons";
import { PixelText } from "./Deco";
import { REGISTER_URL } from "../config";

function Lightbox({ onClose }: { onClose: () => void }) {
  const closeRef = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [onClose]);

  return (
    <div
      className="fade-in fixed inset-0 z-[80] grid place-items-center bg-black/85 p-5 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Phóng to mã QR"
      onClick={onClose}
    >
      <div className="pop-in w-full max-w-[380px] rounded-[24px] bg-white p-6" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="f-display text-lg text-[#060606]">QUÉT MÃ ĐỂ NHẬN</h2>
            <p className="f-mono mt-0.5 text-sm text-[#060606]/55">AI PLUS · 12 tháng miễn phí</p>
          </div>
          <button
            ref={closeRef}
            onClick={onClose}
            aria-label="Đóng"
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full border-2 border-[#060606] text-[#060606] transition hover:bg-[#060606] hover:text-white"
          >
            <CloseIcon size={16} />
          </button>
        </div>
        <img src={qrImg} alt="Mã QR đăng ký Google AI Plus cho sinh viên" className="mt-5 w-full" />
        <a
          href={REGISTER_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="f-mono mt-5 flex items-center justify-center gap-2 rounded-full bg-[#060606] px-6 py-3.5 text-sm font-bold uppercase tracking-wide text-white transition hover:bg-[#00e5ff] hover:text-[#060606]"
        >
          Mở trang đăng ký <ArrowUpRight size={16} />
        </a>
      </div>
    </div>
  );
}

export default function QRTicket() {
  const tilt = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);

  const onMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const el = tilt.current;
    if (!el || e.pointerType === "touch") return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    el.style.transform = `perspective(1000px) rotateY(${px * 8}deg) rotateX(${-py * 8}deg)`;
  };
  const onLeave = () => {
    if (tilt.current) tilt.current.style.transform = "perspective(1000px) rotateY(0deg) rotateX(0deg)";
  };

  return (
    <div className="relative w-full" onPointerMove={onMove} onPointerLeave={onLeave}>
      <div className="floaty">
        <div
          ref={tilt}
          className="relative rotate-[2deg] transition-transform duration-200 ease-out will-change-transform"
          style={{ transform: "perspective(1000px) rotate(2deg)" }}
        >
          {/* sticker MIỄN PHÍ */}
          <div className="absolute -left-4 -top-5 z-20 -rotate-[8deg] rounded-xl border-2 border-[#f4f4f4] bg-[#060606] px-4 py-2.5 shadow-[6px_7px_0_#00e5ff]">
            <PixelText text="FREE" className="text-[20px]" accent="#00e5ff" accentChars="F" />
            <div className="f-mono mt-0.5 text-[9px] uppercase tracking-[0.2em] text-[#f4f4f4]/60">12 months · 0đ</div>
          </div>

          <div className="relative overflow-hidden rounded-[22px] bg-[#f4f4f4] p-5 shadow-[10px_12px_0_rgba(0,229,255,0.9)]">
            {/* header */}
            <div className="mb-4 flex items-center justify-between">
              <span className="f-mono flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.18em] text-[#060606]">
                <span className="blink-dot h-2 w-2 rounded-full bg-[#060606]" /> student pass
              </span>
              <span className="f-mono text-[11px] font-bold text-[#060606]/50">GSA · 2026</span>
            </div>

            {/* QR */}
            <button
              type="button"
              onClick={() => setOpen(true)}
              aria-label="Phóng to mã QR"
              className="group relative block w-full overflow-hidden rounded-[14px] bg-white p-3 transition hover:opacity-95 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#060606]"
            >
              <img src={qrImg} alt="Mã QR đăng ký Google AI Plus miễn phí cho sinh viên" className="mx-auto block w-full max-w-[240px]" width={610} height={610} />
              <span className="pointer-events-none absolute bottom-3 left-1/2 flex -translate-x-1/2 items-center gap-1.5 rounded-full bg-[#060606]/90 px-3 py-1.5 font-mono text-[10px] font-bold uppercase tracking-wide text-white opacity-0 shadow-lg transition group-hover:opacity-100">
                <ExpandIcon size={12} /> phóng to
              </span>
            </button>

            {/* chân vé */}
            <div className="mt-4 flex items-center justify-between border-t-2 border-dashed border-[#060606]/25 pt-3.5">
              <span className="f-mono text-[11px] font-bold uppercase tracking-[0.14em] text-[#060606]/60">hạn · 12 tháng</span>
              <span className="f-mono text-[11px] font-bold uppercase tracking-[0.14em] text-[#060606]">google ai plus</span>
            </div>

            {/* link */}
            <a
              href={REGISTER_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="group mt-4 flex w-full items-center justify-between gap-3 rounded-full bg-[#060606] px-4 py-3 font-mono text-[12px] font-bold uppercase tracking-wide text-white transition hover:bg-[#00e5ff] hover:text-[#060606]"
            >
              <span className="min-w-0 truncate">truy cập · one.google.com/ai-stud…</span>
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-white text-[#060606] transition group-hover:rotate-45">
                <ArrowUpRight size={15} />
              </span>
            </a>
          </div>
        </div>
      </div>
      {open && <Lightbox onClose={() => setOpen(false)} />}
    </div>
  );
}
