import { useEffect, useState } from "react";
import ThreeScene from "./components/ThreeScene";
import QRTicket from "./components/QRTicket";
import Faq from "./components/Faq";
import { BigRing, CornerTicks, GhostWord, OutlineNum, PixelText, QuestionCircle, Spark4, XMark } from "./components/Deco";
import { useReveal } from "./hooks/useReveal";
import { spotlightProps, useCountUp, useScrollProgress, useShowAfter } from "./hooks/useUI";
import { BENEFITS, REGISTER_URL, STEPS, TERMS } from "./config";
import {
  ArrowRight,
  ArrowUpRight,
  BrainIcon,
  CloudIcon,
  FilmIcon,
  NotebookIcon,
  Rocket,
  ScanIcon,
  ShieldCheck,
} from "./components/Icons";

type IconCmp = React.ComponentType<{ size?: number; className?: string }>;
const BENEFIT_ICON: Record<string, IconCmp> = { gemini: BrainIcon, notebook: NotebookIcon, media: FilmIcon, cloud: CloudIcon };
const STEP_ICON: Record<string, IconCmp> = { scan: ScanIcon, verify: ShieldCheck, launch: Rocket };
const ext = { target: "_blank", rel: "noopener noreferrer" } as const;

function ScrollProgress() {
  const p = useScrollProgress();
  return (
    <div className="fixed inset-x-0 top-0 z-[70] h-[3px] bg-transparent" aria-hidden="true">
      <div className="h-full origin-left bg-[#00e5ff]" style={{ transform: `scaleX(${p})` }} />
    </div>
  );
}

/* ------------------------------------------------------------------ */
function Hero() {
  return (
    <section id="top" className="relative">
      <div className="relative mx-auto w-full max-w-[1400px] overflow-hidden bg-[#060606] px-3 pt-3 sm:px-5 sm:pt-4">
        {/* khung poster */}
        <div className="relative overflow-hidden rounded-[26px] border border-[#2e2e2e] sm:rounded-[32px]">
          <CornerTicks className="pointer-events-none absolute inset-2 z-30" />

          {/* Cảnh 3D */}
          <ThreeScene className="pointer-events-none absolute inset-0 z-0" />
          {/* grain nhẹ trên nền */}
          <div className="noise-bg pointer-events-none absolute inset-0 z-[1] opacity-[0.05]" />

          {/* ghost word */}
          <GhostWord className="right-[2%] top-[8%] z-[1] text-[34vw] lg:text-[26vw]">ai</GhostWord>

          {/* nội dung */}
          <div className="relative z-10 grid grid-cols-1 gap-10 px-5 pb-16 pt-6 sm:px-8 sm:pb-20 sm:pt-8 lg:grid-cols-12 lg:gap-8 lg:px-12 lg:pb-16 lg:pt-9">
            {/* Cột trái: sticker + pill + CTA */}
            <div className="min-w-0 pt-6 lg:col-span-7 lg:pt-0">
              {/* sticker #AI+ */}
              <div className="rise relative inline-block" style={{ animationDelay: "0.05s" }}>
                <BigRing className="absolute -right-10 -top-8 hidden h-24 w-24 sm:block lg:-right-14 lg:h-32 lg:w-32" thick={12} />
                <div className="relative -rotate-[8deg] rounded-2xl border-2 border-[#f4f4f4] bg-[#0a0a0a] px-5 py-3.5 shadow-[7px_8px_0_rgba(0,229,255,0.85)] sm:px-6 sm:py-4">
                  <PixelText text="#AI+" className="text-[clamp(34px,5vw,52px)]" accent="#00e5ff" accentChars="#" block />
                  <div className="f-mono mt-1 text-[11px] uppercase tracking-[0.3em] text-[#f4f4f4]/70">plus market</div>
                </div>
                <XMark className="absolute -bottom-8 left-1/2 h-9 w-9 -translate-x-1/2 -rotate-[10deg] text-[#f4f4f4] sm:-bottom-9" />
              </div>

              {/* pill trung tâm */}
              <div className="rise mt-14 flex justify-center lg:mt-16 lg:justify-start" style={{ animationDelay: "0.18s" }}>
                <div className="noise-pill scanlines relative overflow-hidden rounded-full px-8 py-4 shadow-[0_30px_60px_-20px_rgba(0,0,0,0.9)] ring-1 ring-white/15 sm:px-14 sm:py-6 lg:pl-14">
                  <span
                    className="f-display glitch text-[clamp(40px,5.6vw,72px)] leading-none tracking-tight text-[#f4f4f4]"
                    data-text="AI PLUS"
                    style={{ textShadow: "2px 0 rgba(0,229,255,0.5), -2px 0 rgba(244,244,244,0.25)" }}
                  >
                    AI PLUS
                  </span>
                </div>
              </div>

              <p className="rise mt-7 max-w-[34rem] text-[15px] leading-relaxed text-[#a3a3a3] sm:text-base" style={{ animationDelay: "0.32s" }}>
                <b className="text-[#f4f4f4]">Google Student Ambassador</b> tặng sinh viên Việt Nam 12 tháng AI PLUS miễn phí — Gemini nâng cao,
                NotebookLM, tạo ảnh &amp; video, lưu trữ Google One. Quét mã, xác minh là xong.
              </p>

              <div className="rise mt-8 flex flex-wrap items-center gap-3" style={{ animationDelay: "0.45s" }}>
                <a
                  href={REGISTER_URL}
                  {...ext}
                  className="shine relative inline-flex items-center gap-3 overflow-hidden rounded-full bg-[#f4f4f4] px-7 py-4 text-[15px] font-extrabold text-[#060606] shadow-[0_0_0_1px_rgba(255,255,255,0.08),0_18px_40px_-18px_rgba(0,229,255,0.55)] transition hover:-translate-y-0.5 hover:bg-[#00e5ff] hover:shadow-[0_0_40px_rgba(0,229,255,0.35)] sm:text-base"
                >
                  Đăng ký ngay <ArrowRight size={19} />
                </a>
                <a
                  href="#steps"
                  className="inline-flex items-center gap-2 rounded-full border-2 border-[#f4f4f4]/70 px-6 py-3.5 text-[15px] font-bold text-[#f4f4f4] transition hover:border-[#00e5ff] hover:text-[#00e5ff] sm:text-base"
                >
                  Xem hướng dẫn
                </a>
              </div>

              <div className="rise f-mono mt-7 flex flex-wrap gap-x-6 gap-y-1 text-[11px] uppercase tracking-[0.2em] text-[#5f5f5f]" style={{ animationDelay: "0.55s" }}>
                <span>12 months</span>
                <span>0đ · 0 thẻ</span>
                <span>18+ students</span>
                <span className="text-[#00e5ff]">sheerid ✓</span>
              </div>
            </div>

            {/* Cột phải: QR + ký hiệu */}
            <div className="relative min-w-0 lg:col-span-5">
              <div className="f-mono rise mb-6 text-right text-[11px] leading-relaxed tracking-[0.15em] text-[#a3a3a3] lg:mt-2" style={{ animationDelay: "0.4s" }}>
                when you need
                <br />
                AI to study —
                <br />
                it's on.
              </div>
              <div className="rise relative mx-auto w-full max-w-[320px] lg:ml-auto" style={{ animationDelay: "0.35s" }}>
                <XMark className="absolute -left-10 top-1/3 hidden h-8 w-8 rotate-12 text-[#f4f4f4]/80 lg:block" />
                <QRTicket />
              </div>
              {/* # và 12 outline */}
              <span className="f-display pointer-events-none absolute -right-2 top-[38%] hidden select-none text-[110px] leading-none text-[#f4f4f4] lg:block" aria-hidden="true">
                #
              </span>
              <OutlineNum className="absolute -bottom-2 -right-4 hidden text-[170px] lg:block">12</OutlineNum>
            </div>
          </div>

          {/* góc: ? circle + 2026 */}
          <div className="absolute left-5 top-[38%] z-10 hidden lg:block">
            <QuestionCircle className="h-12 w-12 text-[#f4f4f4]/80" />
          </div>
          <div className="absolute right-6 top-6 z-20 flex flex-col items-end gap-1.5">
            <span className="f-mono text-[10px] uppercase tracking-[0.3em] text-[#5f5f5f]">gsa.vn</span>
            <span className="f-display rounded-full border-2 border-[#f4f4f4] px-4 py-1 text-2xl leading-none text-[#f4f4f4]">
              202<span className="text-[#00e5ff]">6</span>
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
function StatValue({ n, plain }: { n?: number; plain?: string }) {
  const { ref, value } = useCountUp(n ?? 0);
  const cls = "f-display text-[46px] leading-none text-[#f4f4f4]";
  if (plain) return <span className={cls}>{plain}</span>;
  return (
    <span ref={ref} className={cls}>
      {value}
    </span>
  );
}

function Stats() {
  const stats = [
    { n: 12, u: "mo", l: "tháng miễn phí trọn vẹn" },
    { plain: "0đ", u: "", l: "chi phí đăng ký" },
    { n: 3, u: "step", l: "bước là xong" },
    { plain: "∞", u: "", l: "ý tưởng cùng Gemini" },
  ];
  return (
    <section className="mx-auto w-full max-w-[1400px] px-5 pt-14 sm:px-8">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s, i) => (
          <div
            key={s.l}
            {...spotlightProps()}
            className="reveal card-dark card-lift spotlight group relative overflow-hidden rounded-[20px] px-5 py-6 hover:border-[#00e5ff]/60"
            style={{ ["--d" as string]: `${i * 80}ms` }}
          >
            <span className="absolute inset-x-0 top-0 h-[3px] bg-[#00e5ff] opacity-0 transition group-hover:opacity-100" />
            <div className="relative">
              <span className="flex items-baseline gap-2">
                <StatValue n={s.n} plain={s.plain} />
                {s.u && <span className="f-mono text-sm uppercase tracking-wide text-[#00e5ff]">{s.u}</span>}
              </span>
              <div className="f-mono mt-3 text-[11px] uppercase tracking-[0.18em] text-[#5f5f5f]">{s.l}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function SectionTitle({ eyebrow, children, sub }: { eyebrow: string; children: React.ReactNode; sub?: string }) {
  return (
    <div className="reveal mb-12 max-w-2xl">
      <span className="f-mono inline-flex items-center gap-2 text-[13px] uppercase tracking-[0.24em] text-[#00e5ff]">
        <span className="text-[#f4f4f4]">#</span> {eyebrow}
      </span>
      <h2 className="f-display mt-4 text-[clamp(32px,4.6vw,56px)] leading-[1.02] text-[#f4f4f4]">{children}</h2>
      {sub && <p className="mt-4 text-lg leading-relaxed text-[#a3a3a3]">{sub}</p>}
    </div>
  );
}

/* ------------------------------------------------------------------ */
function Benefits() {
  return (
    <>
    <div className="mx-auto my-10 w-full max-w-[1400px] px-5 sm:px-8" aria-hidden="true"><div className="section-rule" /></div>
    <section id="benefits" className="mx-auto w-full max-w-[1400px] scroll-mt-24 px-5 pt-24 sm:px-8 sm:pt-32">
      <SectionTitle eyebrow="loot_table" sub="Một gói — đủ công cụ cho học tập, nghiên cứu và sáng tạo suốt năm học.">
        Bộ công cụ AI cho sinh viên
      </SectionTitle>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {BENEFITS.map((b, i) => {
          const Icon = BENEFIT_ICON[b.key];
          const featured = i === 0;
          return (
            <article
              key={b.key}
              {...spotlightProps()}
              className={`reveal card-lift spotlight group relative overflow-hidden rounded-[24px] p-6 ${
                featured ? "card-cyan" : "card-dark hover:border-[#00e5ff]/50"
              }`}
              style={{ ["--d" as string]: `${i * 90}ms` }}
            >
              <span aria-hidden="true" className={`f-display outline-faint pointer-events-none absolute -right-2 -top-5 text-[92px] leading-none ${featured ? "opacity-25" : ""}`} style={featured ? { WebkitTextStroke: "2px rgba(6,6,6,0.35)" } : undefined}>
                0{i + 1}
              </span>
              <div className={`relative grid h-14 w-14 place-items-center rounded-2xl border-2 transition duration-300 group-hover:scale-110 ${featured ? "border-[#060606] bg-[#060606] text-[#00e5ff]" : "border-[#3a3a3a] bg-[#0d0d0d] text-[#f4f4f4] group-hover:border-[#00e5ff]"}`}>
                <Icon size={28} />
              </div>
              <h3 className={`relative mt-6 f-display text-[19px] tracking-tight ${featured ? "text-[#060606]" : "text-[#f4f4f4]"}`}>{b.title}</h3>
              <p className={`relative mt-2 text-[15px] leading-relaxed ${featured ? "text-[#060606]/75" : "text-[#a3a3a3]"}`}>{b.desc}</p>
            </article>
          );
        })}
      </div>
    </section>
    </>
  );
}

/* ------------------------------------------------------------------ */
function Steps() {
  return (
    <>
    <div className="mx-auto my-10 w-full max-w-[1400px] px-5 sm:px-8" aria-hidden="true"><div className="section-rule" /></div>
    <section id="steps" className="mx-auto w-full max-w-[1400px] scroll-mt-24 px-5 pt-24 sm:px-8 sm:pt-32">
      <SectionTitle eyebrow="walkthrough" sub="Chỉ vài phút. Chuẩn bị sẵn tài khoản Google cá nhân và thẻ sinh viên.">
        3 bước nhận AI PLUS miễn phí
      </SectionTitle>
      <div className="grid gap-4 md:grid-cols-3">
        {STEPS.map((s, i) => {
          const Icon = STEP_ICON[s.key];
          return (
            <article
              key={s.n}
              {...spotlightProps()}
              className="reveal card-dark card-lift spotlight group relative overflow-hidden rounded-[24px] p-6 hover:border-[#00e5ff]/60"
              style={{ ["--d" as string]: `${i * 120}ms` }}
            >
              <div className="relative flex items-start justify-between">
                <div className="grid h-16 w-16 place-items-center rounded-2xl bg-[#00e5ff] text-[#060606] transition duration-300 group-hover:-rotate-6">
                  <Icon size={30} />
                </div>
                <OutlineNum className="outline-cyan text-[76px]">{s.n}</OutlineNum>
                {i < 2 && (
                  <span className="f-mono absolute right-[-18px] top-1/2 z-10 hidden h-9 w-9 -translate-y-1/2 place-items-center rounded-full border-2 border-[#3a3a3a] bg-[#060606] text-[#00e5ff] md:grid" aria-hidden="true">
                    <ArrowRight size={15} />
                  </span>
                )}
              </div>
              <h3 className="relative mt-6 f-display text-[21px] text-[#f4f4f4]">{s.title}</h3>
              <p className="relative mt-2 leading-relaxed text-[#a3a3a3]">{s.desc}</p>
            </article>
          );
        })}
      </div>
    </section>
    </>
  );
}

/* ------------------------------------------------------------------ */
function FaqSection() {
  return (
    <>
    <div className="mx-auto my-10 w-full max-w-[1400px] px-5 sm:px-8" aria-hidden="true"><div className="section-rule" /></div>
    <section id="faq" className="mx-auto w-full max-w-[1400px] scroll-mt-24 px-5 pt-24 sm:px-8 sm:pt-32">
      <div className="grid gap-10 lg:grid-cols-12 lg:gap-12">
        <div className="lg:col-span-5">
          <div className="lg:sticky lg:top-28">
            <SectionTitle eyebrow="faq" sub="Những thắc mắc phổ biến nhất khi đăng ký ưu đãi.">
              Băn khoăn gì đó?
            </SectionTitle>
            <div className="reveal -mt-4 rounded-[22px] border border-[#232323] bg-[#0b0b0b] p-5">
              <div className="f-mono flex items-center gap-2 text-[11px] uppercase tracking-[0.2em] text-[#00e5ff]">
                <span className="blink-dot h-2 w-2 rounded-full bg-[#00e5ff]" /> mẹo nhanh
              </div>
              <ul className="mt-3 grid gap-2 text-[14px] leading-relaxed text-[#a3a3a3]">
                <li className="flex gap-2"><span className="f-mono text-[#5f5f5f]">→</span> Dùng tài khoản Google cá nhân, không dùng mail trường.</li>
                <li className="flex gap-2"><span className="f-mono text-[#5f5f5f]">→</span> Chuẩn bị ảnh thẻ sinh viên rõ nét để xác minh nhanh.</li>
                <li className="flex gap-2"><span className="f-mono text-[#5f5f5f]">→</span> Tắt tự gia hạn sau khi kích hoạt nếu không muốn tiếp tục.</li>
              </ul>
              <a href={REGISTER_URL} {...ext} className="mt-5 inline-flex items-center gap-2 rounded-full bg-[#f4f4f4] px-6 py-3.5 font-extrabold text-[#060606] transition hover:-translate-y-0.5 hover:bg-[#00e5ff]">
                Bắt đầu đăng ký <ArrowUpRight size={18} />
              </a>
            </div>
          </div>
        </div>
        <div className="lg:col-span-7">
          <Faq />
        </div>
      </div>
    </section>
    </>
  );
}

/* ------------------------------------------------------------------ */
function Terms() {
  return (
    <section id="terms" className="mx-auto w-full max-w-[1400px] scroll-mt-24 px-5 pb-16 pt-24 sm:px-8 sm:pt-32">
      <div className="reveal relative overflow-hidden rounded-[30px] border border-[#232323] bg-[#0a0a0a]">
        <GhostWord className="-right-6 top-2 text-[24vw]">#</GhostWord>
        <div className="noise-bg pointer-events-none absolute inset-0 opacity-[0.05]" />
        <div className="relative grid gap-10 p-8 sm:p-12 lg:grid-cols-12 lg:items-center">
          <div className="lg:col-span-7">
            <span className="f-mono text-[13px] uppercase tracking-[0.24em] text-[#00e5ff]">#read_me</span>
            <h3 className="f-display mt-4 text-[clamp(30px,4vw,48px)] leading-[1.05] text-[#f4f4f4]">
              Đọc nhanh <span className="text-[#00e5ff]">trước khi</span> đăng ký
            </h3>
            <ul className="mt-7 grid gap-3">
              {TERMS.map((t) => (
                <li key={t} className="flex gap-3 text-[15px] leading-relaxed text-[#a3a3a3]">
                  <span className="f-mono mt-0.5 shrink-0 text-[#00e5ff]">[✓]</span>
                  {t}
                </li>
              ))}
            </ul>
          </div>
          <div className="lg:col-span-5">
            <div className="rounded-[24px] bg-[#f4f4f4] p-7 text-[#060606]">
              <div className="f-mono flex items-center gap-2 text-[11px] uppercase tracking-[0.2em] text-[#060606]/60">
                <span className="blink-dot h-2 w-2 rounded-full bg-[#060606]" /> ready?
              </div>
              <div className="f-display mt-3 text-2xl">Sẵn sàng chưa?</div>
              <div className="mt-1 text-sm font-semibold text-[#060606]/60">Chỉ mất vài phút để xác minh.</div>
              <a href={REGISTER_URL} {...ext} className="shine relative mt-6 flex items-center justify-center gap-2 overflow-hidden rounded-full bg-[#060606] px-6 py-4 font-extrabold text-white transition hover:bg-[#00e5ff] hover:text-[#060606]">
                Nhận ưu đãi ngay <ArrowRight size={18} />
              </a>
              <a href="#top" className="mt-3 flex items-center justify-center gap-2 rounded-full border-2 border-[#060606]/25 px-6 py-3 text-sm font-bold text-[#060606] transition hover:border-[#060606]">
                Quay lại mã QR
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
function FinalCTA() {
  return (
    <section className="mx-auto w-full max-w-[1400px] px-5 pb-4 sm:px-8">
      <div className="reveal relative overflow-hidden rounded-[30px] border border-[#232323] bg-[#060606] px-6 py-16 text-center sm:py-24">
        <div className="pointer-events-none absolute -left-20 -top-20 h-64 w-64 rounded-full bg-[#00e5ff]/10 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 -right-16 h-72 w-72 rounded-full bg-[#00e5ff]/10 blur-3xl" />
        <GhostWord className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-[42vw]">12</GhostWord>
        <div className="relative">
          <PixelText text="#AI+" className="text-[clamp(26px,3.4vw,40px)]" accent="#00e5ff" accentChars="#" block />
          <h2 className="f-display mx-auto mt-5 max-w-3xl text-[clamp(34px,5.4vw,68px)] leading-[1.0] text-[#f4f4f4]">
            12 THÁNG = <span className="text-[#00e5ff]">0Đ</span>
          </h2>
          <p className="f-mono mx-auto mt-5 max-w-xl text-[12px] uppercase tracking-[0.22em] leading-relaxed text-[#5f5f5f]">
            it's a year of free AI for students · no card required
          </p>
          <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
            <a href={REGISTER_URL} {...ext} className="shine relative inline-flex items-center gap-3 overflow-hidden rounded-full bg-[#f4f4f4] px-8 py-4 font-extrabold text-[#060606] transition hover:-translate-y-0.5 hover:bg-[#00e5ff]">
              Đăng ký ngay <ArrowRight size={19} />
            </a>
            <a href="#top" className="inline-flex items-center gap-2 rounded-full border-2 border-[#f4f4f4]/60 px-7 py-3.5 font-bold text-[#f4f4f4] transition hover:border-[#00e5ff] hover:text-[#00e5ff]">
              Quét mã QR
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Thanh điều hướng nổi + scroll-spy */
const NAV = [
  { id: "benefits", label: "Ưu đãi" },
  { id: "steps", label: "Hướng dẫn" },
  { id: "faq", label: "Hỏi đáp" },
  { id: "terms", label: "Điều kiện" },
];

function FloatingNav() {
  const show = useShowAfter("#top");
  const [active, setActive] = useState("");

  useEffect(() => {
    const els = NAV.map((n) => document.getElementById(n.id)).filter(Boolean) as HTMLElement[];
    const io = new IntersectionObserver(
      (entries) => {
        const vis = entries.filter((e) => e.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio);
        if (vis[0]) setActive(vis[0].target.id);
      },
      { rootMargin: "-35% 0px -55% 0px", threshold: [0, 0.25, 0.5, 1] }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  return (
    <nav
      aria-label="Điều hướng nhanh"
      data-show={show}
      className="nav-float fixed left-1/2 top-4 z-[65] hidden items-center gap-1 rounded-full border border-[#2e2e2e] bg-[#0a0a0a]/85 p-1.5 shadow-[0_18px_40px_-16px_rgba(0,0,0,0.9)] backdrop-blur-xl lg:flex"
    >
      <a href="#top" className="flex items-center gap-2 rounded-full px-3 py-2" aria-label="Về đầu trang">
        <Spark4 className="h-3.5 w-3.5 text-[#00e5ff]" />
        <span className="f-display text-sm text-[#f4f4f4]">AI+</span>
      </a>
      <span className="mx-1 h-5 w-px bg-[#2e2e2e]" aria-hidden="true" />
      {NAV.map((n) => (
        <a
          key={n.id}
          href={`#${n.id}`}
          aria-current={active === n.id ? "true" : undefined}
          className={`rounded-full px-4 py-2 text-[13px] font-semibold transition ${
            active === n.id ? "bg-[#f4f4f4] text-[#060606]" : "text-[#a3a3a3] hover:text-[#f4f4f4]"
          }`}
        >
          {n.label}
        </a>
      ))}
      <a href={REGISTER_URL} {...ext} className="ml-1 inline-flex items-center gap-1.5 rounded-full bg-[#00e5ff] px-4 py-2 text-[13px] font-extrabold text-[#060606] transition hover:bg-[#f4f4f4]">
        Đăng ký <ArrowRight size={14} />
      </a>
    </nav>
  );
}

function MobileCTA() {
  const show = useShowAfter("#top");
  if (!show) return null;
  return (
    <div className="slide-up fixed inset-x-0 bottom-0 z-[60] border-t-2 border-[#00e5ff]/40 bg-[#060606]/95 px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 backdrop-blur-xl lg:hidden">
      <div className="flex items-center gap-3">
        <Spark4 className="h-5 w-5 shrink-0 text-[#00e5ff]" />
        <div className="min-w-0 flex-1">
          <div className="f-mono truncate text-[13px] font-bold uppercase tracking-wide text-[#f4f4f4]">AI PLUS · 12 tháng</div>
          <div className="truncate text-[11px] font-semibold text-[#5f5f5f]">Miễn phí cho sinh viên Việt Nam</div>
        </div>
        <a href={REGISTER_URL} {...ext} className="inline-flex shrink-0 items-center gap-2 rounded-full bg-[#f4f4f4] px-5 py-3 text-sm font-extrabold text-[#060606]">
          Đăng ký <ArrowRight size={16} />
        </a>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
export default function App() {
  useReveal();
  return (
    <div className="page-bg relative min-h-screen overflow-x-clip">
      <div className="page-grain" />
      <ScrollProgress />
      <FloatingNav />
      <main className="relative">
        <Hero />
        <Stats />
        <Benefits />
        <Steps />
        <FaqSection />
        <Terms />
        <FinalCTA />
      </main>
      <footer className="mx-auto w-full max-w-[1400px] px-5 pb-24 sm:px-8 lg:pb-10">
        <div className="h-px bg-[#232323]" />
        <div className="f-mono flex flex-col items-center gap-3 py-8 text-center text-[12px] uppercase tracking-[0.18em] text-[#5f5f5f] sm:flex-row sm:justify-between sm:text-left">
          <span className="flex items-center gap-2 text-[#f4f4f4]">
            <Spark4 className="h-3 w-3 text-[#00e5ff]" /> gsa · vietnam
          </span>
          <span>© {new Date().getFullYear()} · Google &amp; Gemini are trademarks of Google LLC</span>
        </div>
      </footer>
      <MobileCTA />
    </div>
  );
}
