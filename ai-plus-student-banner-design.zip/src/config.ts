// Cấu hình nội dung banner – chỉnh tại đây
// Link này khớp với mã QR trong src/assets/qr.png
export const REGISTER_URL =
  "https://one.google.com/ai-student?utm_source=g1&utm_medium=paid_social&utm_campaign=slap_3_campus_vn-gsa-ambassador-phamvanhoang-GSAVN27010452_offer&g1_landing_page=75";
export const REGISTER_LABEL = "one.google.com/ai-student";

export const BENEFITS = [
  {
    key: "gemini",
    title: "Gemini nâng cao",
    desc: "Mô hình mạnh nhất với giới hạn cao hơn – giải bài tập, viết luận, lập trình và nghiên cứu sâu.",
  },
  {
    key: "notebook",
    title: "NotebookLM",
    desc: "Tải tài liệu, slide, bài giảng lên và để AI tổng hợp, đặt câu hỏi, tạo audio ôn tập cho bạn.",
  },
  {
    key: "media",
    title: "Tạo ảnh & video AI",
    desc: "Biến ý tưởng thành hình ảnh và video sống động cho bài thuyết trình, dự án, CLB.",
  },
  {
    key: "cloud",
    title: "Lưu trữ Google One",
    desc: "Thêm dung lượng cho Drive, Gmail và Google Photos – thoải mái lưu tài liệu suốt năm học.",
  },
];

export const STEPS = [
  {
    n: "01",
    key: "scan",
    title: "Quét mã QR",
    desc: "Mở camera điện thoại, quét mã trên banner để tới trang đăng ký ưu đãi dành cho sinh viên.",
  },
  {
    n: "02",
    key: "verify",
    title: "Xác minh sinh viên",
    desc: "Đăng nhập tài khoản Google cá nhân và xác minh tư cách sinh viên qua SheerID trong vài phút.",
  },
  {
    n: "03",
    key: "launch",
    title: "Kích hoạt & khám phá",
    desc: "Hoàn tất đăng ký, nhận ngay 12 tháng AI PLUS và bắt đầu học thông minh hơn cùng Gemini.",
  },
];

export const TERMS = [
  "Dành cho sinh viên Việt Nam từ 18 tuổi trở lên, xác minh qua SheerID.",
  "Sử dụng tài khoản Google cá nhân (không dùng tài khoản trường cấp).",
  "Hết 12 tháng ưu đãi, gói có thể tự động gia hạn theo giá chuẩn – hãy hủy trước nếu không muốn tiếp tục.",
  "Điều kiện và thời hạn áp dụng theo công bố chính thức của Google.",
];

export const FAQS = [
  {
    q: "Mình có cần thẻ thanh toán không?",
    a: "Google có thể yêu cầu thêm phương thức thanh toán để xác thực tài khoản. Trong 12 tháng ưu đãi bạn không bị tính phí; hãy tắt tự động gia hạn nếu không muốn tiếp tục sau đó.",
  },
  {
    q: "Email trường của mình không được nhận diện thì sao?",
    a: "SheerID cho phép tải lên giấy tờ thay thế như thẻ sinh viên, giấy xác nhận sinh viên hoặc bảng điểm có tên và năm học.",
  },
  {
    q: "Mình đang dùng Google One rồi, có đăng ký được không?",
    a: "Tài khoản đang có gói Google One hoặc AI Pro/Ultra trả phí thường không đủ điều kiện. Bạn có thể dùng một tài khoản Google cá nhân khác.",
  },
  {
    q: "Ưu đãi áp dụng cho bao nhiêu thiết bị?",
    a: "Gói gắn với tài khoản Google của bạn, nên bạn đăng nhập ở điện thoại, máy tính hay máy tính bảng đều dùng được.",
  },
];

